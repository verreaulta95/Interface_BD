﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labfinal.ViewModele
{
    public class BaseViewModel
    {
        // Attributs
        private string connexionString;

        // Gets/Sets
        public string ConnexionString
        {
            get { return connexionString; }
            private set
            {
                connexionString = value;
            }
        }
    }
}
