﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Labfinal.Modele;
using Labfinal.Commandes;
using System.Windows.Controls;
using System.Windows;
using System.Diagnostics;

namespace Labfinal.ViewModele
{
    public class JeuViewModel : BaseViewModel, INotifyPropertyChanged
    {
        // Attributs
        private BaseViewModel selectedViewModel;
        private Jeu jeu;
        private BaseCommand commandeAjout;
        private BaseCommand commandeLancerJeu;
        private BaseCommand commandeTrierJeu;
        private BaseCommand commandeTrierGenre;
        private Joueur joueur;
        private Button ButonNomJeu;

        // Gets/Sets
        #region Gets/Sets
        public BaseViewModel SelectedViewModel
        {
            get { return selectedViewModel; }
            set
            {
                selectedViewModel = value;
                OnPropertyChanged("SelectedViewModel");
            }
        }

        public Jeu Jeux
        {
            get { return jeu; }
            set
            {
                jeu = value;
                OnPropertyChanged("Jeux");
            }
        }

        public Joueur Joueur
        {
            get { return joueur; }
            set { 
                joueur = value;
                OnPropertyChanged("Joueur"); 
            }
        }

        public BaseCommand CommandeAjouter
        {
            get { return commandeAjout; }
            set
            {
                commandeAjout = value;
            }
        }

        public BaseCommand CommandeLancerJeu
        {
            get { return commandeLancerJeu; }
            set
            {
                commandeLancerJeu = value;
            }
        }

        public BaseCommand CommandeTrierJeu
        {
            get { return commandeTrierJeu; }
            set
            {
                commandeTrierJeu = value;
            }
        }

        public BaseCommand CommandeTrierGenre
        {
            get { return commandeTrierGenre; }
            set
            {
                commandeTrierGenre = value;
            }
        }

        public ObservableCollection<Button> ListeControl
        {
            get;
            set;
        }

        public Button BoutonNomJeu
        {
            get { return ButonNomJeu; }
            set
            {
                ButonNomJeu = value;
                OnPropertyChanged("BoutonNomJeux");
            }
        }
        #endregion Gets/Sets

        // Constructeur
        public JeuViewModel(Joueur joueur)
        {
            SelectedViewModel = this;
            Joueur = joueur;
            ListeControl = new ObservableCollection<Button>();
            jeu = new Jeu();
            LoadListeJeux();            
            CommandeAjouter = new BaseCommand(AjouterJeux, obj => true);
            CommandeTrierJeu = new BaseCommand(TrierJeux, obj => true);
            CommandeTrierGenre = new BaseCommand(TrierGenreJeux, obj => true);
        }

        // Fonctions
        public void AjouterJeux(object p)
        {
            string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
            SqlConnection con = new SqlConnection(ConnexionString);
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO tblJeu VALUES (@param1, @param2, @param3, @param4)", con);
            // Ajoute les données du jeu et les associe avec les parametres
            command.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = Jeux.Nom;
            command.Parameters.Add("@param2", SqlDbType.VarChar, 120).Value = Jeux.Emplacement;
            command.Parameters.Add("@param3", SqlDbType.VarChar,25).Value = Jeux.Genre;
            command.Parameters.Add("@param4", SqlDbType.Int).Value = Joueur.Identifiant;
            command.ExecuteNonQuery();
            LoadListeJeux();            
            con.Close();
        }

        public void LoadListeJeux()
        {
            string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
            SqlConnection con = new SqlConnection(ConnexionString);
            con.Open();
            SqlCommand command = new SqlCommand("SELECT nom, emplacement, genre FROM tblJeu where idJoueur=@param1", con);
            command.Parameters.Add("@param1", SqlDbType.Int).Value = Joueur.Identifiant;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "tblJeu");

            ListeControl.Clear();
            foreach (DataRow row in dataSet.Tables[0].Rows)
            {                
                BoutonNomJeu = new Button();
                Button BoutonGenreJeu = new Button();
                object valueLargeur = 120.0;
                object valueHauteur = 20.0;
                
                Style styleBoutton = new Style(typeof(Button));
                styleBoutton.Setters.Add(new Setter(Button.WidthProperty, valueLargeur));
                styleBoutton.Setters.Add(new Setter(Button.HeightProperty, valueHauteur));
                BoutonNomJeu.Style = styleBoutton;
                BoutonGenreJeu.Style = styleBoutton;

                BoutonNomJeu.Command = new BaseCommand(JeuxEstLancer, obj => true);
                BoutonNomJeu.CommandParameter = row[1].ToString();  // Passe l'emplacement en parametre pour la commande, ce qui permet d'execute le seul selon son emplacement
                BoutonNomJeu.Content = row[0].ToString();           // Nom du jeu
                BoutonGenreJeu.Content = row[2].ToString();         // Genre du jeu
                
                ListeControl.Add(BoutonNomJeu);                     // Ajoute le bouton qui est relié au nom du jeu
                ListeControl.Add(BoutonGenreJeu);                   // Ajoute le bouton qui est relié au genre du jeu
            }
            con.Close();
        }

        public void TrierJeux(object p)
        {
            string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
            SqlConnection con = new SqlConnection(ConnexionString);
            con.Open();
            SqlCommand command = new SqlCommand("SELECT nom, emplacement FROM tblJeu WHERE idJoueur=@param1 ORDER BY tblJeu.Nom ASC", con);
            command.Parameters.Add("@param1", SqlDbType.Int).Value = Joueur.Identifiant;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "tblJeu");

            ListeControl.Clear();
            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                BoutonNomJeu = new Button();
                object valueLargeur = 120.0;
                object valueHauteur = 20.0;

                Style styleBoutton = new Style(typeof(Button));
                styleBoutton.Setters.Add(new Setter(Button.WidthProperty, valueLargeur));
                styleBoutton.Setters.Add(new Setter(Button.HeightProperty, valueHauteur));
                BoutonNomJeu.Style = styleBoutton;

                BoutonNomJeu.Command = new BaseCommand(JeuxEstLancer, obj => true);
                BoutonNomJeu.CommandParameter = row[1].ToString();
                BoutonNomJeu.Content = row[0].ToString();

                ListeControl.Add(BoutonNomJeu);
            }
            con.Close();
        }

        public void TrierGenreJeux(object p)
        {
            string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
            SqlConnection con = new SqlConnection(ConnexionString);
            con.Open();
            SqlCommand command = new SqlCommand("SELECT nom, emplacement FROM tblJeu WHERE idJoueur=@param1 ORDER BY tblJeu.Genre ASC", con);
            command.Parameters.Add("@param1", SqlDbType.Int).Value = Joueur.Identifiant;
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, "tblJeu");

            ListeControl.Clear();
            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                BoutonNomJeu = new Button();
                object valueLargeur = 120.0;
                object valueHauteur = 20.0;
                object vertical = "left";

                Style styleBoutton = new Style(typeof(Button));
                styleBoutton.Setters.Add(new Setter(Button.WidthProperty, valueLargeur));
                styleBoutton.Setters.Add(new Setter(Button.HeightProperty, valueHauteur));
                BoutonNomJeu.Style = styleBoutton;

                BoutonNomJeu.Command = new BaseCommand(JeuxEstLancer, obj => true);
                BoutonNomJeu.CommandParameter = row[1].ToString();
                BoutonNomJeu.Content = row[0].ToString();

                ListeControl.Add(BoutonNomJeu);
            }
            con.Close();
        }

        public void JeuxEstLancer(object p)
        {
            Process.Start(p.ToString());
        }

        // Interface INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string nom = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nom));
        }
    }
}
