﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Labfinal.View;
using Labfinal.Modele;
using Labfinal.Commandes;
using System.Data.SqlClient;
using System.Data;
using System.Windows;

namespace Labfinal.ViewModele
{
    public class MainViewModel : BaseViewModel, INotifyPropertyChanged
    {
        // Attributs
        private Joueur utilisateur;
        private Jeu jeux;
        private BaseViewModel selectedViewModel;
        private BaseCommand commandInscription;
        private BaseCommand commandConnexion;
        private BaseCommand saveCommand;

        // Gets et Sets
        #region Gets/Sets
        public Joueur Utilisateur
        {
            get { return utilisateur; }
            set
            {
                utilisateur = value;
                OnPropertyChanged("Utilisateur");
            }
        }

        public Jeu Jeux
        {
            get { return jeux; }
            set
            {
                jeux = value;
                OnPropertyChanged("Jeux");
            }
        }

        public BaseViewModel SelectedViewModel
        {
            get { return selectedViewModel; }
            set
            {
                selectedViewModel = value;
                OnPropertyChanged("SelectedViewModel");
            }
        }

        public BaseCommand CommandInscription
        {
            get { return commandInscription; }
            set
            {
                commandInscription = value;
            }
        }

        public BaseCommand CommandConnexion
        {
            get { return commandConnexion; }
            set
            {
                commandConnexion = value;
            }
        }

        public BaseCommand SaveCommand
        {
            get { return saveCommand; }
            set
            {
                saveCommand = value;
            }
        }

        #endregion Gets/Sets

        // Constructeur
        public MainViewModel()
        {
            SelectedViewModel = this;
            Utilisateur = new Joueur();
            Jeux = new Jeu();
            CommandInscription = new BaseCommand(Inscription, obj => true);
            CommandConnexion = new BaseCommand(SeConnecteDb, obj => true);
            SaveCommand = new BaseCommand(SaveData, obj => true);
        }

        // Fonctions
        public void Inscription(object p)
        {
            Inscription fenetreInscription = new Inscription();
            fenetreInscription.DataContext = SelectedViewModel;
            fenetreInscription.Show();
        }

        public void SeConnecteDb(object p)
        {
            try
            {
                // La chaine de connexion qui me permet d'accéder a la base de donnée
                string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
                bool connexionAutorise = false;

                // Fait la connexion avec Sql Server
                SqlConnection con = new SqlConnection(ConnexionString);

                // Ouvre une connexion avec Sql Server
                con.Open();

                // Permet d'executer une requête avec la base de donnée (Select, procédure, etc)
                SqlCommand command = new SqlCommand("SELECT TOP 1 id FROM tblJoueur where courriel=@param1 AND motDePasse=@param2", con);
                command.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = Utilisateur.AdresseCourriel;
                command.Parameters.Add("@param2", SqlDbType.VarChar, 25).Value = Utilisateur.Password;
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "tblJoueur");



                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    Utilisateur.Identifiant = Convert.ToInt32(row[0]);                    
                    connexionAutorise = true;
                }

                if(connexionAutorise == true)
                {
                    PageJeux pageJeu = new PageJeux();
                    pageJeu.DataContext = new JeuViewModel(Utilisateur);
                    pageJeu.Show();   
                }
                con.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show("Une erreur est survenue");
            }
        }

        public void SaveData(object p)
        {            
            string ConnexionString = "Data Source = deptinfo420; Initial Catalog = BD_AlexFinal; Integrated Security = True";
            SqlConnection con = new SqlConnection(ConnexionString);
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO tblJoueur VALUES (@param1, @param2,@param5,@param3,@param4)", con);
            // Ajoute les données de l'utilisateur et les associe avec les parametres
            command.Parameters.Add("@param1", SqlDbType.VarChar,25).Value = Utilisateur.Nom;
            command.Parameters.Add("@param2", SqlDbType.VarChar, 25).Value = Utilisateur.Prenom;
            command.Parameters.Add("@param3", SqlDbType.VarChar, 25).Value = Utilisateur.AdresseCourriel;
            command.Parameters.Add("@param4", SqlDbType.VarChar, 25).Value = Utilisateur.Password;
            command.Parameters.Add("@param5", SqlDbType.Int).Value = Utilisateur.Naissance;
            command.ExecuteNonQuery();
            con.Close();
        }

        // Interface INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string nom = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nom));
        }
    }
}
