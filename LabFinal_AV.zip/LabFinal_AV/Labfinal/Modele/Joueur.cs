﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Labfinal.Modele
{
    public class Joueur : INotifyPropertyChanged
    {
        // Attributs
        private int identifiant;
        private string nom;
        private string prenom;
        private int naissance;
        private string adresseCourriel;
        private string password;

        // Gets et Sets
        #region Gets/Sets

        public int Identifiant
        {
            get { return identifiant; }
            set
            {
                identifiant = value;
                OnPropertyChanged("Identifiant");
            }
        }

        public string Nom
        {
            get { return nom; }
            set
            {
                nom = value;
                OnPropertyChanged("Nom");
            }
        }

        public string Prenom
        {
            get { return prenom; }
            set
            {
                prenom = value;
                OnPropertyChanged("Prenom");
            }
        }

        public int Naissance
        {
            get { return naissance; }
            set
            {
                naissance = value;
                OnPropertyChanged("Naissance");
            }
        }

        public string AdresseCourriel
        {
            get { return adresseCourriel; }
            set
            {
                adresseCourriel = value;
                OnPropertyChanged("AdresseCourriel");
            }
        }
        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                OnPropertyChanged("Password");
            }
        }

        #endregion

        // Constructeur
        public Joueur()
        {
            Identifiant = 0;
            Nom = "";
            Prenom = "";
            Naissance = 0;
            AdresseCourriel = "";
            Password = "";
        }

        // Interface INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string property = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
}
