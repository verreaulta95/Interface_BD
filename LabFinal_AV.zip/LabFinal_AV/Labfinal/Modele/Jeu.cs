﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace Labfinal.Modele
{
    public class Jeu : INotifyPropertyChanged
    {
        // Attributs
        private int identifiant;
        private string nom;
        private string emplacement;
        private string genre;
        private int identifiantJoueur;

        // Gets et Sets
        #region Gets/Sets

        public int Identifiant
        {
            get { return identifiant; }
            set 
            { 
                identifiant = value;
                OnPropertyChanged("Identifiant");
            }
        }

        public string Nom
        {
            get { return nom; }
            set
            {
                nom = value;
                OnPropertyChanged("Nom");
            }
        }

        public string Emplacement
        {
            get { return emplacement; }
            set
            {
                emplacement = value;
                OnPropertyChanged("Emplacement");
            }
        }

        public string Genre
        {
            get { return genre; }
            set
            {
                genre = value;
                OnPropertyChanged("Genre");
            }
        }

        public int IdentifiantJoueur
        {
            get { return identifiantJoueur; }
            set
            {
                identifiantJoueur = value;
            }
        }

        #endregion

        // Constructeur
        public Jeu()
        {
            Identifiant = 0;
            Nom = "";
            Emplacement = "";
            Genre = "";
            IdentifiantJoueur = 0;
        }
        
        // Interface INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string property = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
}
