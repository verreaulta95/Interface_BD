/* --- Script 1 - Creation de base de donnee --- */

/* Interface et Base de donnée : Lab final */

/* Alex Verreault */

/* --- Creation de la base de donnee BD_AlexFinal --- */

DROP DATABASE IF EXISTS BD_AlexFinal;

CREATE DATABASE BD_AlexFinal;

USE BD_AlexFinal;

/* Création de la table du joueur */
DROP TABLE IF EXISTS tblJoueur;
CREATE TABLE tblJoueur
(
	id				int				IDENTITY(1,1),
	nom				varchar(50)		NOT NULL,
	prenom			varchar(50)		NOT NULL,
	naissance 		int				NOT NULL,
	courriel		varchar(50)		NOT NULL,
	motDePasse		varchar(25)		NOT NULL
)

/* Création de la table du joueur */
DROP TABLE IF EXISTS tblJeu;
CREATE TABLE tblJeu
(
	id				int				IDENTITY(1,1),
	nom				varchar(50) 	NOT NULL,
	emplacement		varchar(120)	NOT NULL,
	genre			varchar(25)		NOT NULL,
	idJoueur		int				NOT NULL
)

use master;