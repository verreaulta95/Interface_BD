/* --- Script de creation de contraintes --- */

/* Interface et Base de donnée : Lab final */

/* Alex Verreault */

/* Base de donnée : BD_AlexFinal */

use BD_AlexFinal;

/* Creation des contraintes */

/* Cle primaires */

ALTER TABLE tblJoueur ADD PRIMARY KEY (id);
ALTER TABLE tblJeu ADD PRIMARY KEY (id);

/* Cle secondaires	 */ 

ALTER TABLE tblJeu ADD FOREIGN KEY (idJoueur) REFERENCES tblJoueur(id);

use master;