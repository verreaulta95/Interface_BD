USE BD_AlexFinal;

INSERT INTO tblJoueur VALUES ('Verreault','Alex',02121995,'test@hotmail.com','test123');
INSERT INTO tblJeu VALUES ('Ark','C:/jeu/Ark','survie',1);

use master;